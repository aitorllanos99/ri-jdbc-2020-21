rm test.lck
rm test.log
rm test.data
rm test.script
rm -r test.tmp

cp test.script.bck test.script
